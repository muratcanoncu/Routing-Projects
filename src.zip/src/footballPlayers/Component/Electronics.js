import React from "react";

function Electronics() {
  return <h2>Electronics section</h2>;
}

export default Electronics;
