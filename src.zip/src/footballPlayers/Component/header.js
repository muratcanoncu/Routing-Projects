import React, { Component } from "react";
import Footer from "./footer";

export default class header extends Component {
  render() {
    return (
      <div>
        <Footer></Footer>
      </div>
    );
  }
}
