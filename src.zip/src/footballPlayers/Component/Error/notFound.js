import React from "react";

function notFound() {
  return (
    <div>
      <h1>Page not Found-404!</h1>
    </div>
  );
}

export default notFound;
